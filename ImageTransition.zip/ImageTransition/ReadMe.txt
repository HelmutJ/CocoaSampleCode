ImageTransition
===============

Demonstrates how to use Core Image's built-in transition filters and Core Animation's 
built-in transition types to transition between images.  This sample accompanies the 
Core Image Programming Guide, using "Core Image Filters" section.


===========================================================================
BUILD REQUIREMENTS:

Xcode 3.2, Mac OS X 10.6 Snow Leopard or later

===========================================================================
RUNTIME REQUIREMENTS:

Mac OS X 10.6 Snow Leopard or later

===========================================================================
CHANGES FROM PREVIOUS VERSIONS:

Version 1.1
- Updated classes to use properties.
- Project updated for Xcode 4.
Version 1.0
- First version.


===========================================================================
Copyright (C) 2011 Apple Inc. All rights reserved.