### PlayFile ###

===========================================================================
DESCRIPTION:

The PlayFile project provides example code for simple audio file read and playback using the AudioFile API for reading the file, and the AudioFilePlayer and DefaultOutput units for playback

===========================================================================
BUILD REQUIREMENTS:

Mac OS X v10.7 or later
Xcode v4.3 or later

===========================================================================
RUNTIME REQUIREMENTS:

Mac OS X v10.7 or later

===========================================================================
PACKAGING LIST:

PlayFile.cpp
- Main file for project

===========================================================================
CHANGES FROM PREVIOUS VERSIONS:

Version 1.0
- First version.

===========================================================================
Copyright (C) 2009 Apple Inc. All rights reserved.
