These extra patches are those which are very powerful and exciting, but would not fit into the PinBall example. They are each stand-alone and display one single concept.

Sample and Hold - Demonstrates how to hold a value
Queue - Demonstrates how to hold a series of values
Timelines - Outputs arbitrary values over time
Network Receiver - Works in conjunction with the Network Broadcaster
Network Broadcaster - Works in conjunction with the Network Receiver to synchronize values.
