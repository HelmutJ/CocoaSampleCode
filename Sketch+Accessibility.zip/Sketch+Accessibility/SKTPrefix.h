//
// Prefix header for all source files of the 'Sketch' target in the 'Sketch+Accessibility' project
//

#ifdef __OBJC__
#import <Cocoa/Cocoa.h>
#endif

