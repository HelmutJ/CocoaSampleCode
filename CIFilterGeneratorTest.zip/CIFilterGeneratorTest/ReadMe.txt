
### CIFilterGeneratorTest ###

===========================================================================
DESCRIPTION:

Creating, saving and loading a CIFilterGenerator and using it as a filter, all in one sample.

===========================================================================
BUILD REQUIREMENTS:

Xcode 4.4 or later, Mac OS X v10.7 or later

===========================================================================
RUNTIME REQUIREMENTS:

Mac OS X v10.7 or later

===========================================================================
CHANGES FROM PREVIOUS VERSIONS:

Version 1.1
- Updated for Xcode 4.4.

Version 1.0
- First version.

===========================================================================
Copyright (C) 2009-2012 Apple Inc. All rights reserved.
