Simply open this file in Quartz Composer and show
the input parameters in order to select the input
image. Note you will have to disable the effect
to select the points initially. Then, once you're
done you can enable the effect and try adjusting
the values of the parameters a and b to see how they
influence the final rendering.
