### CIAnnotation ###

===========================================================================
DESCRIPTION:

The CIAnnotation application shows compositing, painting, Appkit/CG rendering into a CIImage as well as exporting a CIImage and printing. It includes 2 custom Image Units that demonstrate how to write your own CIFilter.

===========================================================================
BUILD REQUIREMENTS:

Mac OS X v10.5

===========================================================================
RUNTIME REQUIREMENTS:

Mac OS X v10.5


===========================================================================
CHANGES FROM PREVIOUS VERSIONS:

Version 1.0
- First version.

===========================================================================
Copyright (C) 2009 Apple Inc. All rights reserved.
