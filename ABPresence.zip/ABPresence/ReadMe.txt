ABPresence
v1.0

This sample application displays a list of all of the people in your Address Book 
and displays the appropriate status gem for that person based on their iChat status.

The application registers for notifications from iChat through IMService, so it will
display up-to-date status information as people log in and out or as their status changes.
