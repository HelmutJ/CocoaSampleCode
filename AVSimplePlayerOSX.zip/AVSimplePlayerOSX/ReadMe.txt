### AVSimplePlayerOSX ###

===========================================================================
DESCRIPTION:

A simple AV Foundation document based movie playback application.

===========================================================================
BUILD REQUIREMENTS:

Xcode 4.0 or later, Mac OS X v10.7 or later

===========================================================================
RUNTIME REQUIREMENTS:

Mac OS X 10.7 or later

===========================================================================
PACKAGING LIST:

AVSPDocument.m/h:
 The document class. This contains the application logic.

AVSPDocument.xib:
 The document NIB. This contains the application UI.

===========================================================================
CHANGES FROM PREVIOUS VERSIONS:

Version 1.0
- First version.

===========================================================================
Copyright (C) 2011 Apple Inc. All rights reserved.
