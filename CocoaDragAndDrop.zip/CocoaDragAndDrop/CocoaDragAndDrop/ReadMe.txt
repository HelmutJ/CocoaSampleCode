CocoaDragAndDrop
================

ABOUT:

CocoaDragAndDrop is a sample that demonstrates how to implement drag and drop functionality in Cocoa using images but this method can easily be extended to deal with other types of data.



===========================================================================
BUILD REQUIREMENTS:

Xcode 4.1, Mac OS X 10.7 Lion or later

===========================================================================
RUNTIME REQUIREMENTS:

Mac OS X 10.7 Lion or later

===========================================================================
CHANGES FROM PREVIOUS VERSIONS:

Version 1.1
- Rewrote code for drag source with the new APIs.
- Source code formatting cleanup.
- Project updated for Xcode 4.
Version 1.0
- First version.

===========================================================================
Copyright (C) 2002-2011 Apple Inc. All rights reserved.



