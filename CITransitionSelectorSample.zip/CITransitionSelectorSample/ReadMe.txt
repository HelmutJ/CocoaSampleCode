
### CITransitionSelectorSample ###

===========================================================================
DESCRIPTION:

Illustrates how to use CoreImage filters to use transition effects and play several of them at the same time.

===========================================================================
BUILD REQUIREMENTS:

Xcode 4.4 or later, OS X v10.7 or later

===========================================================================
RUNTIME REQUIREMENTS:

OS X v10.7 or later


===========================================================================
CHANGES FROM PREVIOUS VERSIONS:

Version 1.1
- Updated for Xcode 4.4.

Version 1.0
- First version.

===========================================================================
Copyright (C) 2009-2012 Apple Inc. All rights reserved.
