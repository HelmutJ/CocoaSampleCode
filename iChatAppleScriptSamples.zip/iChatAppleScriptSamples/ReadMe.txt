iChat AppleScript Samples
v1.0

There are five samples included in this package:

Add Incoming Images to iPhoto
Uses an "Incoming File Transfer" to import photos into iPhoto.

Find Accounts by Name
Queries iChat for all available accounts matching a specified name.

Text Commands
Uses a "Message Sent" handler to search outgoing messages for commands.

Chatbot-Eliza
Uses a "Message Received" handler to interface with Chatbot-Eliza, a virtual psychotherapist.

TuneBot
Uses a "Message Received" handler to interface with iTunes.


Requires Leopard.