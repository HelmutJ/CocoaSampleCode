
### CIMicroPaint ###

===========================================================================
DESCRIPTION:

This very simple paint program shows how to use the CIImageAccumulator API to paint.

===========================================================================
BUILD REQUIREMENTS:

Xcode 4.4 or later, OS X v10.7 or later

===========================================================================
RUNTIME REQUIREMENTS:

OS X v10.7 or later

===========================================================================
CHANGES FROM PREVIOUS VERSIONS:

Version 1.1
- Updated for Xcode 4.4.

Version 1.0
- First version.

===========================================================================
Copyright (C) 2009-2012 Apple Inc. All rights reserved.
