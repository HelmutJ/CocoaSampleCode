### ReaderWriter ###

===========================================================================
DESCRIPTION:

AVReaderWriter demonstrates how to use AVAssetReader to read and decode sample data from a movie file, work directly with the sample data, then use AVAssetWriter to encode and write the sample data to a new movie file.

===========================================================================
BUILD REQUIREMENTS:

Xcode 4.0 or later, Mac OS X v10.7 or later

===========================================================================
RUNTIME REQUIREMENTS:

Mac OS X v10.7 or later

===========================================================================
PACKAGING LIST:

<< Describe important files here >>

===========================================================================
CHANGES FROM PREVIOUS VERSIONS:

Version 1.0
- First version.

===========================================================================
Copyright (C) 2011 Apple Inc. All rights reserved.
