### PlaySoftMIDI ###

===========================================================================
DESCRIPTION:

The PlaySoftMIDI project uses a sequence of audio units, including the DLSSynth, PeakLimiter, and DefaultOutput units, to play back a specified MIDI file.

===========================================================================
BUILD REQUIREMENTS:

Mac OS X v10.6 or later

===========================================================================
RUNTIME REQUIREMENTS:

Mac OS X v10.6 or later

===========================================================================
PACKAGING LIST:

main.cpp
- The main file for the project

===========================================================================
CHANGES FROM PREVIOUS VERSIONS:

Version 1.0
- First version.

===========================================================================
Copyright (C) 2009 Apple Inc. All rights reserved.
