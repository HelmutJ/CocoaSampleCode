### CIDemoImageUnit ###

===========================================================================
DESCRIPTION:

Demonstrates how to wrap two filters in an Image Unit which can be used by any Image Unit hosts, for example "Core Image Fun House".

===========================================================================
BUILD REQUIREMENTS:

Xcode 3.1 or later, Mac OS X v10.6 or later

===========================================================================
RUNTIME REQUIREMENTS:

Mac OS X v10.6 or later

===========================================================================
CHANGES FROM PREVIOUS VERSIONS:

Version 1.0
- First version.

===========================================================================
Copyright (C) 2009 Apple Inc. All rights reserved.
