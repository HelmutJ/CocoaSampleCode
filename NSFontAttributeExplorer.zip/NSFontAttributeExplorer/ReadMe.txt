NSFontAttributeExplorer
=======================

Demonstrates how to gather and display various metric information for installed fonts using NSFont APIs. This sample is useful if you need to know font metric information and how to gather that information via the various APIs.

===========================================================================
Sample Requirements
The supplied Xcode project was created using Xcode v4.3 and OS X 10.7.x or later running under Mac OS X 10.6.x or later.

===========================================================================	
Changes from Previous Versions

1.0 - First release.
1.1 - Upgraded to Xcode 4.3 and Mac OS X 10.7


Copyright (C) 2004-2012 Apple Inc. All rights reserved.