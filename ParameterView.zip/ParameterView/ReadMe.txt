Copyright © 2007-2009 by Apple Inc.  All Rights Reserved.

Quartz Composer Application

ParameterView				An application that demonstrates how to use the 
					QCCompositionParameterView in combination with a QCView and 
					the Composition Repository API to render a composition and 
					display its parameters for user to edit.

Sample Requirements			The project was created using the Xcode running under 						Mac OS X 10.6.x or later. 

About the sample			This sample shows how to select a composition with a 						popup button and render it in QCView. The parameters of 
					the selected composition will also be shown in the 
					QCParameterView window.

Using the Sample			Open the project using the Xcode editor which can be 						found in /Developer/Applications. Build the project and 
					run. Change the parameters to see different results.

Installation				n/a

Changes from Previous Versions		n/a

Feedback and Bug Reports		Please send all feedback about this sample to:
					http://developer.apple.com/contact/feedback.html

					Please submit any bug reports about this example to 
					http://developer.apple.com/bugreport

