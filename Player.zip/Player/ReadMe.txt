Copyright © 2007-2009 by Apple Inc.  All Rights Reserved.

Quartz Composer Application

Player						A simple full-screen composition player that uses the 
						QCRenderer API.

Sample Requirements				The project was created using the Xcode running under 
						Mac OS X 10.6.x or later. 

About the sample				This sample uses QCRenderer to render a Quartz Composer 
						composition through OpenGL in a window. The sample asks the 
						user to choose a composition, once the composition is 
						selected, it is rendered full screen through QCRenderer.

Using the Sample				Open the project using the Xcode editor which can be found 
						in /Developer/Applications. Build the project and run.

Installation					n/a
	
Changes from Previous Versions			n/a

Feedback and Bug Reports			Please send all feedback about this sample to:
						http://developer.apple.com/contact/feedback.html

						Please submit any bug reports about this example to 
						http://developer.apple.com/bugreport

