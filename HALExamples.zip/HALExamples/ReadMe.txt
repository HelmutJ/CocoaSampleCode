### HALExamples ###

===========================================================================
DESCRIPTION:

HALExamples provide sample code for usage of the CoreAudio HAL API available in the CoreAudio framework. ConfigDefaultOutput is a simple command line utility to display all available output devices, and/or set the default output device of the system

===========================================================================
BUILD REQUIREMENTS:

Mac OS X v10.6 or later

===========================================================================
RUNTIME REQUIREMENTS:

Mac OS X v10.6 or later

===========================================================================
PACKAGING LIST:

ConfigDefaultOutput.c
	Command line utility to display available output devices and set the system default output device
===========================================================================
CHANGES FROM PREVIOUS VERSIONS:

Version 1.0
- First version.

===========================================================================
Copyright (C) 2009 Apple Inc. All rights reserved.
