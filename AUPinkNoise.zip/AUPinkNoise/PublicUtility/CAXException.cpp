/*
 <codex> 
 <abstract>CAXException.h</abstract>
 <\codex>
*/
#include "CAXException.h"

CAXException::WarningHandler CAXException::sWarningHandler = NULL;
