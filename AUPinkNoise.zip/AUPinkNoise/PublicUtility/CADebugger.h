/*
 <codex> 
 <abstract>Part of CoreAudio Utility Classes</abstract>
 <\codex>
*/
#if !defined(__CADebugger_h__)
#define __CADebugger_h__

//=============================================================================
//	CADebugger
//=============================================================================

extern void	CADebuggerStop();

#endif
