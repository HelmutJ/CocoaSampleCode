#ifndef __AUPinkNoiseVersion_h__
#define __AUPinkNoiseVersion_h__


#ifdef DEBUG
	#define kAUPinkNoiseVersion 0xFFFFFFFF
#else
	#define kAUPinkNoiseVersion 0x00010000	
#endif

//~~~~~~~~~~~~~~  Change!!! ~~~~~~~~~~~~~~~~~~~~~//
#define AUPinkNoise_COMP_SUBTYPE		'pink'
#define AUPinkNoise_COMP_MANF		'appl'
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

#endif

