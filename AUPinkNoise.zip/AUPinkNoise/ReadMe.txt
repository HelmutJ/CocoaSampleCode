### AUPinkNoise ###

===========================================================================
DESCRIPTION:

The AUPinkNoise project will build an audio unit generator that creates a pink noise output. The project provides an example of how to create an audio unit generator with a simple Cocoa view

===========================================================================
BUILD REQUIREMENTS:

Mac OS X v10.7 or later

===========================================================================
RUNTIME REQUIREMENTS:

Mac OS X v10.7 or later

===========================================================================
PACKAGING LIST:

AUPinkNoise.h
AUPinkNoise.cpp
- The main source files for generating the pink noise signal and managing the audio unit's properties

===========================================================================
CHANGES FROM PREVIOUS VERSIONS:

Version 1.0
- First version.

===========================================================================
Copyright (C) 2012 Apple Inc. All rights reserved.
