DataBurn

DataBurn demonstrates basic features of the DiscRecording framework, and in particular the DRTrack object. The sample shows how to create a DRFolder from an existing folder on a source disk and burn it to disc creating a hybrid ISO9660/Joliet/HFS+ data CD.

The sample also uses the DiscRecordingUI framework to present the standard burn setup and progress user interfaces.

The main functionality is provided in the AppController class. It illustrates how to setup and start a simple single folder data burn.
