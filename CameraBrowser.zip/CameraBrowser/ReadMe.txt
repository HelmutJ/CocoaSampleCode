### CameraBrowser ###

===========================================================================
DESCRIPTION:

This sample project shows how to use the ImageCaptureCore framework classes  to implement a camera client application.

===========================================================================
BUILD REQUIREMENTS:

Xcode 4.4

===========================================================================
RUNTIME REQUIREMENTS:

Mac OS X 10.6

===========================================================================
PACKAGING LIST:


===========================================================================
CHANGES FROM PREVIOUS VERSIONS:

Version 1.2
- Update to use ARC and latest Developer Tools.

Version 1.1
- Updated project to be in sync with final version of ImageCaptureCore framework in SnowLeopard.

Version 1.0
- First version.

===========================================================================
Copyright (C) 2009-2012 Apple Inc. All rights reserved.
