### SimpleCameraBrowser ###

===========================================================================
DESCRIPTION:

This sample project shows how to use the ImageCaptureCore framework classes  to implement a very simple camera client application. It is a companion to the full-featured CameraBrowser sample code.

===========================================================================
BUILD REQUIREMENTS:

Xcode 4.4

===========================================================================
RUNTIME REQUIREMENTS:

Mac OS X 10.6

===========================================================================
CHANGES FROM PREVIOUS VERSIONS:

Version 1.1
- Update to use ARC and latest Developer Tools.

Version 1.0
- First version.

===========================================================================
Copyright (C) 2009-2012 Apple Inc. All rights reserved.
