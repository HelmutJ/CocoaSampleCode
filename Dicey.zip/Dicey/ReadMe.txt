### Dicey ###

===========================================================================
DESCRIPTION:

Dicey is a dice game project that demonstrates making a custom view accessible, making custom sub-elements of a view accessible, as well as adding accessibility attributes to individual UI elements in Interface Builder and in code.


===========================================================================
BUILD REQUIREMENTS:

Tiger 10.4.7 or later

===========================================================================
RUNTIME REQUIREMENTS:

Tiger 10.4.7 or later

===========================================================================
CHANGES FROM PREVIOUS VERSIONS:

Version 1.0
- First version.

===========================================================================
Copyright (C) 2009 Apple Inc. All rights reserved.
