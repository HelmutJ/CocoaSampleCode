#ifndef __SinSynthVersion_h__
#define __SinSynthVersion_h__


#define kSinSynthVersion 0x00010000	
#define kSinSynthSubtype 'jsin'

#endif
