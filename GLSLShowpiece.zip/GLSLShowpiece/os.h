// place all os-specific code in this file

#include <OpenGL/gl.h>
