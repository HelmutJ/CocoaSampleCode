ReadMe for TremoloUnit
-----------------------
TremoloUnit is a C++ sample project that demonstrates how to build a simple effect audio unit 
with a generic view. The TremoloUnit project corresponds to a tutorial in Audio Unit 
Programming Guide, available in the ADC Reference Library at this location:

http://developer.apple.com/documentation/MusicAudio/Conceptual/AudioUnitProgrammingGuide/


Sample Requirements
-------------------
This sample project requires:
	Mac OS X v10.7
	Xcode 4.1 or later

Feedback
--------
To send feedback to Apple about this sample project, use the feedback form at 
this location:

http://developer.apple.com/contact/

===========================================================================
Copyright (C) 2012 Apple Inc. All rights reserved.

