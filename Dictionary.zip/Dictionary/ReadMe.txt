### Dictionary ###

===========================================================================
DESCRIPTION:

Simple CFDictionary example program, also showing property list functionality.

===========================================================================
BUILD REQUIREMENTS:

Xcode 3.1 or l

===========================================================================
RUNTIME REQUIREMENTS:

Xcode 3.2 or later, Mac OS X v10.6 or later

===========================================================================
PACKAGING LIST:

<< Describe important files here >>

===========================================================================
CHANGES FROM PREVIOUS VERSIONS:

Version 1.0
- First version.

===========================================================================
Copyright (C) 2009 Apple Inc. All rights reserved.
